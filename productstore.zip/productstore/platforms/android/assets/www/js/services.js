angular.module('starter.services',[])
.service('WC', function(){
    return {
        WC: function(){
            var Woocommerce = new WooCommerceAPI.WooCommerceAPI({
                url: 'http://farm.techmongers.in',
                consumerKey: 'ck_243422c81e0a9cbed826c5b76bd332bd3ad8008f',
                consumerSecret: 'cs_bda85e640173f18fe84bf463c1f58dfa277f24dc'
            });
            return Woocommerce;
        }
}});
