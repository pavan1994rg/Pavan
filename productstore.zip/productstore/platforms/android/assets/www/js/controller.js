angular.module('starter.controllers',[])

.controller('menuCtrl',function($scope,WC){

})

.controller('homeCtrl',function($scope,WC,$state){
$scope.data={};
$scope.login=function(){
  console.log($scope.data.username);
  console.log($scope.data.password);
  if($scope.data.username=="admin"){
    $state.go("app.admin");
  }
  else{
    $state.go("app.user");
  }
}


})
.controller('categoriesCtrl',function($scope,WC){


})
.controller('adminCtrl',function($scope,$http){
  $scope.data={};
  $scope.add=function(){
  $http.get("http://localhost/productstore/upload.php?name="+$scope.data.name+"&productdesp="+$scope.data.productdesp+"&price="+$scope.data.price).then(function(data){
    console.log(data);
  })
}
})
.controller('userCtrl',function($scope){

})
.controller('imageCtrl',function($scope,$cordovaCamera){
  var options = {
                   quality: 75,
                   destinationType: Camera.DestinationType.DATA_URL,
                   sourceType: Camera.PictureSourceType.CAMERA,
                   allowEdit: true,
                   encodingType: Camera.EncodingType.JPEG,
                   targetWidth: 300,
                   targetHeight: 300,
                   popoverOptions: CameraPopoverOptions,
                   saveToPhotoAlbum: false
               };

                   $cordovaCamera.getPicture(options).then(function (imageData) {
                       $scope.imgURI = "data:image/jpeg;base64," + imageData;
                   
                   });



})
